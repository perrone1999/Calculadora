/*
 * Proyecto sobre ejercicios de Stacks o Pilas,
 * haciendo uso de Interface y ADT.
 * Ejercicio 12.
 */
package problema12;

/**
 * Clase con main para ejercicio de Parentesis Balanceados
 * @author EDg1
 */
public class problema12main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RevisorParentesis rp1;
        boolean b;
        String exprStr, sinoStr;

        // 1er ejemplo de una expresion String
        System.out.println("\n---- PRUEBA 1 ----");
        exprStr = "((7+(10+12)*(40+50/2)+4)*5)-20";
        rp1 = new RevisorParentesis(exprStr);
        b = rp1.parentesisBalan();
        sinoStr = (b) ? "SI" : "NO";
        System.out.println("La expresion string: " + exprStr +
                ", " + sinoStr + " tiene los Parentesis Balanceados\n");

        // 2do ejemplo de una expresion String
        System.out.println("\n---- PRUEBA 2 ----");
        exprStr = "((10+12)))*((40+50/2)";
        rp1 = new RevisorParentesis(exprStr);
        b = rp1.parentesisBalan();
        sinoStr = (b) ? "SI" : "NO";
        System.out.println("La expresion string: " + exprStr +
                ", " + sinoStr + " tiene los Parentesis Balanceados\n");
        
        // 3er ejemplo de una expresion String
        System.out.println("\n---- PRUEBA 3 ----");
        exprStr = "40-8";
        rp1 = new RevisorParentesis(exprStr);
        b = rp1.parentesisBalan();
        sinoStr = (b) ? "SI" : "NO";
        System.out.println("La expresion string: " + exprStr +
                ", " + sinoStr + " tiene los Parentesis Balanceados\n");
        
        // 4to ejemplo de una expresion String
        System.out.println("\n---- PRUEBA 4 ----");
        exprStr = "(40-(8+(((6))))))";
        rp1 = new RevisorParentesis(exprStr);
        b = rp1.parentesisBalan();
        sinoStr = (b) ? "SI" : "NO";
        System.out.println("La expresion string: " + exprStr +
                ", " + sinoStr + " tiene los Parentesis Balanceados\n");
        
    }
    
}
